--LootSquid v1.4 by Tavi

require "Apollo"
require "GameLib"
require "Item"

local LootSquid = {}
local version = 1.4

function LootSquid:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function LootSquid:Init()
	Apollo.RegisterAddon(self)
end

local tDefaultSettings = {
	Mark = false,
	AutoLoot = false,
	Queue = true,
	Hide = false,
	First = true,
	Version = version,
}

local tSettings

local ktAutoLoot = {
	"Divine Class Focus - Major",
	"Divine Class Focus - Minor",
	"Divine Set Focus - Major",
	"Divine Set Focus - Minor",
	"Pure Class Focus - Major",
	"Pure Class Focus - Minor",
	"Pure Set Focus - Major",
	"Pure Set Focus - Minor",
	"Datascape Matrix",
	"Genetic Matrix",
	"Tarnished Eldan Gift",
	"Encrypted Datashard",
}

local ktClassToIcon = {
	[GameLib.CodeEnumClass.Medic]       	= "Icon_Windows_UI_CRB_Medic",
	[GameLib.CodeEnumClass.Esper]       	= "Icon_Windows_UI_CRB_Esper",
	[GameLib.CodeEnumClass.Warrior]     	= "Icon_Windows_UI_CRB_Warrior",
	[GameLib.CodeEnumClass.Stalker]     	= "Icon_Windows_UI_CRB_Stalker",
	[GameLib.CodeEnumClass.Engineer]    	= "Icon_Windows_UI_CRB_Engineer",
	[GameLib.CodeEnumClass.Spellslinger]  	= "Icon_Windows_UI_CRB_Spellslinger",
}

local karItemColors = {
	[Item.CodeEnumItemQuality.Inferior] 		= "ItemQuality_Inferior",
	[Item.CodeEnumItemQuality.Average] 			= "ItemQuality_Average",
	[Item.CodeEnumItemQuality.Good] 			= "ItemQuality_Good",
	[Item.CodeEnumItemQuality.Excellent] 		= "ItemQuality_Excellent",
	[Item.CodeEnumItemQuality.Superb] 			= "ItemQuality_Superb",
	[Item.CodeEnumItemQuality.Legendary] 		= "ItemQuality_Legendary",
	[Item.CodeEnumItemQuality.Artifact]		 	= "ItemQuality_Artifact",
}


function LootSquid:OnLoad()
    self.xmlDoc = XmlDoc.CreateFromFile("LootSquid.xml")
    self.xmlDoc:RegisterCallback("OnDocumentReady", self)

	Apollo.RegisterSlashCommand("ls", "OnSlashCommand", self)
	Apollo.RegisterSlashCommand("lootsquid", "OnSlashCommand", self)

	Apollo.RegisterTimerHandler("CombatCheckTimer", "OnCombatCheckTimer", self)
	Apollo.RegisterTimerHandler("ResizeTimer", "OnResizeTimer", self)
	
	Apollo.RegisterEventHandler("MasterLootUpdate",				"OnMasterLootUpdate", self)
	Apollo.RegisterEventHandler("LootAssigned",					"OnLootAssigned", self)
	Apollo.RegisterEventHandler("Group_Left",					"OnGroup_Left", self)
	Apollo.RegisterEventHandler("GenericEvent_ToggleGroupBag", 	"OnToggleGroupBag", self)
	

	
end

function LootSquid:OnDocumentReady()
    if self.xmlDoc == nil then return end

	if tSettings == nil then
		tSettings = tDefaultSettings
	end
	if tSettings.Version == nil then
		tSettings.Version = version
	elseif tSettings.Version < version then
		tSettings.Version = version
		tSettings.First = true
	end
	--self.wndLoot = Apollo.LoadForm(self.xmlDoc, "Loot", nil, self)
	self.wndSettings = Apollo.LoadForm(self.xmlDoc, "Settings", nil, self)
	self.wndForm = Apollo.LoadForm(self.xmlDoc, "Form", nil, self)
	--self.wndCollapsed = Apollo.LoadForm(self.xmlDoc, "Collapsed", nil, self)
	self.wndMain = self.wndForm:FindChild("Main")
	self.wndItemList = self.wndMain:FindChild("ItemWindow"):FindChild("ItemList")
	self.wndPlayerList = self.wndMain:FindChild("PlayerWindow"):FindChild("PlayerList")
	self.wndOptions = self.wndSettings:FindChild("Options")
	self.wndTitle = self.wndForm:FindChild("Title")
	self.wndConfirm = self.wndMain:FindChild("PlayerWindow"):FindChild("All"):FindChild("Confirm")

	self.tCheckedItems = {}
	self.tItemWindows = {}
	self.tGroupMembers = {}
	self.tPlayerWindows = {}
	self.tItemsToLoot = {}
	self.tQueuedItems = {}
	self.tMemberList = {}
	self.bLeader = false
	math.randomseed(os.time())
	self.wndSettings:Show(tSettings.First)
	tSettings.First = false
	self.wndTitle:FindChild("Show"):Show(tSettings.Hide)
	self.wndTitle:FindChild("Hide"):Show(not tSettings.Hide)
	self.wndConfirm:Show(false)
	local strTooltip = "To edit, find \"ktAutoLoot\" in LootSquid.lua (Line:30): \n \n"
	for idx, strItem in ipairs(ktAutoLoot) do
		strTooltip = strTooltip..strItem.."\n"
	end
	self.wndSettings:FindChild("Options"):FindChild("AutoLoot"):FindChild("Tooltip"):SetTooltip(strTooltip)
	
	if tSettings.MainLocation then
		local l,t,r,b = unpack(tSettings.MainLocation)
		self.wndMain:SetAnchorOffsets(l,t,r,b)
	end
	if tSettings.SettingsLocation then
		local l,t,r,b = unpack(tSettings.SettingsLocation)
		self.wndSettings:SetAnchorOffsets(l,t,r,b)
	end
	if tSettings.FormLocation then
		local l,t,r,b = unpack(tSettings.FormLocation)
		self.wndForm:SetAnchorOffsets(l,t,r,b)
	end
	
	if next(GameLib.GetMasterLoot()) then
		self.wndForm:Show(true)
		self.wndMain:Show(true)
		self:OnMasterLootUpdate()
	else
		self.wndForm:Show(false)
	end

	
end


function LootSquid:OnCombatCheckTimer()
	local PlayerInCombat = GameLib.GetPlayerUnit():IsInCombat()
	if PlayerInCombat then return end
	self:OnMasterLootUpdate()
	Apollo.StopTimer("CombatCheckTimer")
end
	



---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------

function LootSquid:OnMasterLootUpdate()
	local tItemList = GameLib.GetMasterLoot()
	local l,t,r,b = self.wndMain:GetAnchorOffsets()
	tSettings.MainLocation = {l,t,r,b}
	l,t,r,b = self.wndForm:GetAnchorOffsets()
	tSettings.FormLocation = {l,t,r,b}
	local PlayerInCombat = GameLib.GetPlayerUnit():IsInCombat()
	
	if tSettings.Mark and GroupLib.AmILeader() and not GameLib.GetPlayerUnit():GetTargetMarker() then
		GameLib.GetPlayerUnit():SetTargetMarker(4)
	end
	
	self.wndMain:FindChild("PlayerWindow"):Show(GroupLib.AmILeader())
	self.wndForm:Show(true)
	self.wndMain:Show(not tSettings.Hide)
	
	-- update list with items
	if tItemList ~= nil then
		self:RefreshItemList(tItemList)
		if tSettings.Hide then
			self.wndTitle:FindChild("Text"):SetTextColor("xkcdGreen")
		end
	else
		self.tQueuedItems = {}
		self.wndTitle:FindChild("Text"):SetTextColor("xkcdWhite")
	end
	
end

function LootSquid:RefreshItemList(tItemList)
	local nVPos = self.wndItemList:GetVScrollPos()
	
	self.tItemWindows = {}
	self.tCheckedItems = {}
	
	for _,window in pairs(self.wndItemList:GetChildren()) do
		if window:IsChecked() then 
			self.tCheckedItems[window:GetData().nLootId] = true
		end
		window:Destroy()
	end
	
	for idx, tItem in pairs(tItemList) do
		local wndCurrentItem = Apollo.LoadForm(self.xmlDoc, "ListItem", self.wndItemList, self)
		self.tItemWindows[tItem.nLootId] = wndCurrentItem
		wndCurrentItem:FindChild("Icon"):GetWindowSubclass():SetItem(tItem.itemDrop)
		wndCurrentItem:FindChild("Name"):SetText(tItem.itemDrop:GetName())
		wndCurrentItem:FindChild("Name"):SetTextColor(karItemColors[tItem.itemDrop:GetItemQuality()])		
		wndCurrentItem:SetData(tItem)
		
		for _, strItemName in ipairs(ktAutoLoot) do
			if tItem.itemDrop:GetName() == strItemName then
				table.insert(self.tQueuedItems, {item = tItem.nLootId, name = GameLib.GetPlayerUnit():GetName()})
			end
		end
		
		--LootQueue, needs test
		for _, tData in pairs(self.tQueuedItems) do
			if tData.item == tItem.nLootId then
				wndCurrentItem:FindChild("Name"):SetText("(Queued:"..tData.name..") "..tItem.itemDrop:GetName())
				for _, unitLooter in pairs(tItem.tLooters) do
					local strLooterName = unitLooter:GetName()
					if strLooterName == tData.name then
						GameLib.AssignMasterLoot(tData.item, unitLooter)
					end
				end
			end
		end
		
		if self.tCheckedItems[tItem.nLootId] == true then
			wndCurrentItem:SetCheck(true)
			self:RefreshPlayerList(tItem)
		end
	end
	
	self.wndItemList:ArrangeChildrenVert(Window.CodeEnumArrangeOrigin.LeftOrTop)
	self.wndItemList:SetVScrollPos(nVPos)
	
end

function LootSquid:RefreshPlayerList(tItem)
	if tItem == nil then
		--self.wndPlayerList:Show(false)
		for idx, wndPlayer in pairs(self.wndPlayerList:GetChildren()) do
			wndPlayer:Destroy()
		end
		return
	end
	
	local vPos = self.wndPlayerList:GetVScrollPos()
	
	self.tCheckedPlayer = nil
	for _, window in pairs(self.wndPlayerList:GetChildren()) do
		if window:IsChecked() == true then
			self.CheckedPlayer = window:GetName()
		end
		window:Destroy()
	end
	
	local tValidMembers = {}
	local nMemberCount = GroupLib.GetMemberCount()
	self.tMemberList = {}
	for idx = 1, nMemberCount do
		local name = GroupLib.GetGroupMember(idx).strCharacterName
		table.insert(self.tMemberList, name)
		local wndCurrent = Apollo.LoadForm(self.xmlDoc, "ListPlayer", self.wndPlayerList, self)
		wndCurrent:SetData(GroupLib.GetGroupMember(idx))
		wndCurrent:SetName(name)
		self.tPlayerWindows[name] = wndCurrent
		wndCurrent:Show(true)
		wndCurrent:FindChild("Name"):SetText(name)
		wndCurrent:FindChild("Icon"):SetSprite(ktClassToIcon[GroupLib.GetGroupMember(idx).eClassId])
		self.tPlayerWindows[name]:Enable(false)
	end
	
	for idx, unitMember in pairs(tItem.tLooters) do
		local strName = unitMember:GetName()
		local tData = { unit = unitMember, item = tItem, queue = false }

		--self.MemberList[strName].valid = true
		
		self.tPlayerWindows[strName]:Enable(true)
		self.tPlayerWindows[strName]:SetData(tData)
	end
	
	if self.CheckedPlayer ~= nil then
		self.tPlayerWindows[self.CheckedPlayer]:SetCheck(true)
	end
	
	--for item, name in pairs(self.tQueuedItems)
	
	-- get out of range people
	if tItem.tLootersOutOfRange and next(tItem.tLootersOutOfRange) then
		for idx, name in pairs(tItem.tLootersOutOfRange) do
			local tData = { name = name, item = tItem, queue = true}
			--self.MemberList[name].valid = true
			self.tPlayerWindows[name]:FindChild("Name"):SetText(String_GetWeaselString(Apollo.GetString("Group_OutOfRange"), name))
			self.tPlayerWindows[name]:FindChild("Icon"):SetSprite("CRB_GroupFrame:sprGroup_Disconnected")
			self.tPlayerWindows[name]:Enable(true)
			self.tPlayerWindows[name]:SetData(tData)
						
		end
	end
	
	self.wndPlayerList:ArrangeChildrenVert(Window.CodeEnumArrangeOrigin.LeftOrTop, function(a,b)
		return a:FindChild("Name"):GetText() < b:FindChild("Name"):GetText()
	end)
	self.wndPlayerList:SetVscrollPos(vPos)
end
--[[
function LootSquid:RefreshLooterItemList(tLooterItemList)

	local nVPos = self.wndLooter_ItemList:GetVScrollPos()
	local tIndexedList = {}

	for idx, tItem in pairs (tLooterItemList) do
		tIndexedList[tItem.nLootId] = tItem
	
		local wndCurrentItem = self.tLooterLootWindows[tItem.nLootId]
		if wndCurrentItem == nil or not wndCurrentItem:IsValid() then
			wndCurrentItem = Apollo.LoadForm(self.xmlDoc, "LooterItemButton", self.wndLooter_ItemList, self)
			self.tLooterLootWindows[tItem.nLootId] = wndCurrentItem
			
			wndCurrentItem:FindChild("ItemIcon"):GetWindowSubclass():SetItem(tItem.itemDrop)
			wndCurrentItem:FindChild("ItemName"):SetText(tItem.itemDrop:GetName())
			wndCurrentItem:FindChild("ItemName"):SetTextColor(karItemColors[tItem.itemDrop:GetItemQuality()])
			
			-- new item(s) show the window
			self.wndLooter:Show(true)
		end
		
		wndCurrentItem:SetData(tItem)
	end

	for idx, wndItem in pairs(self.wndLooter_ItemList:GetChildren()) do
		local tItem = wndItem:GetData()
		if tIndexedList[tItem.nLootId] ==  nil then
			wndItem:Destroy()
			self.tLooterLootWindows[tItem.nLootId] = nil
		end
	end
	
	self.wndLooter_ItemList:ArrangeChildrenVert(Window.CodeEnumArrangeOrigin.LeftOrTop)
	self.wndLooter_ItemList:SetVScrollPos(nVPos)

end
]]
----------------------------

function LootSquid:OnGroup_Left()
	if self.wndForm:IsShown() then
		self:OnClose()
	end
end

----------------------------

function LootSquid:OnItemGenerateTooltip(wndHandler, wndControl, eToolTipType, x, y)
	if wndHandler ~= wndControl then
		return
	end

	local tItem = wndControl:GetData()	
	if Tooltip ~= nil and Tooltip.GetItemTooltipForm ~= nil then
		Tooltip.GetItemTooltipForm(self, wndControl, tItem.itemDrop, {bPrimary = true, bSelling = false, itemCompare = tItem.itemDrop:GetEquippedItemForItemType()})
	end
end

----------------------------

function LootSquid:OnItemMouseButtonUp(wndHandler, wndControl, eMouseButton) -- Both LooterItemButton and ItemButton
	if eMouseButton == GameLib.CodeEnumInputMouse.Right then
		local tItemInfo = wndHandler:GetData()
		if tItemInfo and tItemInfo.itemDrop then
			Event_FireGenericEvent("GenericEvent_ContextMenuItem", tItemInfo.itemDrop)
		end
	end
end

function LootSquid:OnItemCheck(wndHandler, wndControl, eMouseButton)
	if eMouseButton ~= GameLib.CodeEnumInputMouse.Right then
		if not GroupLib.AmILeader() then wndHandler:SetCheck(false) return end
		local tItemInfo = wndHandler:GetData()
		if tItemInfo then
			table.insert(self.tItemsToLoot, tItemInfo)
			self:RefreshPlayerList(tItemInfo)
		end
	end
end

function LootSquid:OnItemUncheck(wndHandler, wndControl, eMouseButton)
	if eMouseButton ~= GameLib.CodeEnumInputMouse.Right then
		local tItemInfo = wndHandler:GetData()
		if tItemInfo then
			for idx, tItem in ipairs(self.tItemsToLoot) do
				if tItem.nLootId == tItemInfo.nLootId then
					table.remove(self.tItemsToLoot, idx)
				end
			end
		end
		self:RefreshPlayerList(nil)
	end
end
----------------------------
--[[
function LootSquid:OnCharacterMouseButtonUp(wndHandler, wndControl, eMouseButton)
	if eMouseButton == GameLib.CodeEnumInputMouse.Right then
		local unitPlayer = wndControl:GetData() -- Potentially nil
		local strPlayer = wndHandler:FindChild("CharacterName"):GetText()
		if unitPlayer and unitPlayer.unitLooter then
			Event_FireGenericEvent("GenericEvent_NewContextMenuPlayerDetailed", wndHandler, strPlayer, unitPlayer.unitLooter)
		else
			Event_FireGenericEvent("GenericEvent_NewContextMenuPlayer", wndHandler, strPlayer)
		end
	end
end

function LootSquid:OnCharacterCheck(wndHandler, wndControl, eMouseButton)
	if eMouseButton ~= GameLib.CodeEnumInputMouse.Right then
		local tData = wndControl:GetData()
		self.wndMasterLoot:FindChild("Assignment"):SetData(tData)
		self.wndMasterLoot:FindChild("Assignment"):Enable(true)
	end
end

----------------------------

function LootSquid:OnCharacterUncheck(wndHandler, wndControl, eMouseButton)
	if eMouseButton ~= GameLib.CodeEnumInputMouse.Right then
		self.wndMasterLoot:FindChild("Assignment"):Enable(false)
	end
end
]]
----------------------------

function LootSquid:OnAssignLoot(wndHandler, wndControl, eMouseButton)
	local tData = wndHandler:GetData()
	if tData.queue and tData.queue == true then
		for i, itemtoloot in ipairs(self.tItemsToLoot) do
			table.insert(self.tQueuedItems, { item = itemtoloot.nLootId, name = tData.name })
			for _, window in pairs(self.tItemWindows) do
				if window:GetData().nLootId == itemtoloot.nLootId then
					window:FindChild("Name"):SetText("(Queued:"..tData.name..") "..itemtoloot.itemDrop:GetName())
					window:SetCheck(false)
				end
			end
		end
	else
		for idx, Item in ipairs(self.tItemsToLoot) do
			GameLib.AssignMasterLoot(Item.nLootId, tData.unit)
		end
	end
	self.tItemsToLoot = {}
	self:RefreshPlayerList(nil)
end

----------------------------

function LootSquid:OnClose(wndHandler, wndControl, eMouseButton)
	self.wndForm:Show(false)
end

------------------------------------
--[[
function LootSquid:OnCloseLooterWindow()
	self.locSavedLooterWindowLoc = self.wndLooter:GetLocation()
	self.wndLooter:Show(false)
end
]]
----------------------------

function LootSquid:OnLootAssigned(objItem, strLooter)
	Event_FireGenericEvent("GenericEvent_LootChannelMessage", String_GetWeaselString(Apollo.GetString("CRB_MasterLoot_AssignMsg"), objItem:GetName(), strLooter))
end


---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------

function LootSquid:OnCloseWindow( wndHandler, wndControl, eMouseButton )
	local l,t,r,b = self.wndSettings:GetAnchorOffsets()
	tSettings.SettingsLocation = {l,t,r,b}
	self.wndSettings:Show(false)
end

function LootSquid:OnDefaults( wndHandler, wndControl, eMouseButton )
	tSettings = tDefaultSettings
	self:RefreshSettings()
end

function LootSquid:RefreshSettings()
	self.wndOptions:FindChild("Mark"):SetCheck(tSettings.Mark)
	self.wndOptions:FindChild("AutoLoot"):SetCheck(tSettings.AutoLoot)
	--self.wndOptions:FindChild("Queue"):SetCheck(tSettings.Queue)
end

function LootSquid:OnOptionChanged( wndHandler, wndControl, strText )
	local option = wndHandler:GetName()
	if option == nil then return end
	tSettings[option] = wndHandler:GetText()
end

function LootSquid:OnCheckbox( wndHandler, wndControl, eMouseButton )
	local option = wndHandler:GetName()
	if option == nil then return end
	tSettings[option] = wndHandler:IsChecked()
end

function LootSquid:OnSlashCommand()
	self:RefreshSettings()
	if not self.wndForm:IsShown() then
		self.wndForm:Show(true)
	else
		self.wndForm:Show(false)
		Print("Type \"/ls\" to show the loot window again")
	end
end	

function LootSquid:OnOptionsButton( wndHandler, wndControl, eMouseButton )
	if not self.wndSettings:IsShown() then
		self.wndSettings:Show(true)
	else
		self.wndSettings:Show(false)
	end
end

function LootSquid:OnRestore(eLevel, tData)
	if eLevel ~= GameLib.CodeEnumAddonSaveLevel.Character then return end
	if tData then
		tSettings = tData
	end
end

function LootSquid:OnSave(eLevel)
	if eLevel ~= GameLib.CodeEnumAddonSaveLevel.Character then return end
	local l,t,r,b
	
	l,t,r,b = self.wndMain:GetAnchorOffsets()
	tSettings.MainLocation = {l,t,r,b}
	
	l,t,r,b = self.wndForm:GetAnchorOffsets()
	tSettings.FormLocation = {l,t,r,b}
	
	return tSettings
end

function strRound(nSource, nDecimals)
    return tonumber(string.format("%." .. (nDecimals or 0) .. "f", nSource))
end

--GeminiHook things

--local Hook = Apollo.GetPackage("Gemini:Addon-1.1").tPackage:NewAddon("Hook", false, {}, "Gemini:Hook-1.0")
--local bHooked = false
--[[
function Hook:OnEnable()
	Hook:OnHooksReady()
end

function Hook:OnHooksReady()
	if bHooked then return end
	bHooked = true
	--self:RawHook(Apollo.GetAddon(""),"")
end
]]
--


function LootSquid:OnHide( wndHandler, wndControl, eMouseButton )
	self.wndTitle:FindChild("Hide"):Show(false)
	self.wndTitle:FindChild("Show"):Show(true)
	self.wndMain:Show(false)
	tSettings.Hide = true
end

function LootSquid:OnShow( wndHandler, wndControl, eMouseButton )
	self.wndTitle:FindChild("Hide"):Show(true)
	self.wndTitle:FindChild("Show"):Show(false)
	self.wndMain:Show(true)
	tSettings.Hide = false
end


---------------------------------------------------------------------------------------------------
-- Form Functions
---------------------------------------------------------------------------------------------------

function LootSquid:OnMainResize( wndHandler, wndControl )
	Apollo.StopTimer("ResizeTimer")
	Apollo.CreateTimer("ResizeTimer", 0.1, false)
	local l,t,r,b = self.wndForm:GetAnchorOffsets()
	self.formsize = {l,t,r,b}
	if not self.Resized then
		self.Resized = true
	end
end

function LootSquid:OnResizeTimer()
	local l,t,r,b = self.wndMain:GetAnchorOffsets()
	self.wndTitle:SetAnchorOffsets(l,t,r/2,30)
	local d = r - l
	local l,t,r,b = unpack(self.formsize)
	self.wndForm:SetAnchorOffsets(l,t,l + (d/2),t + 30)
	self.Resized = nil
end

function LootSquid:OnAllButton( wndHandler, wndControl, eMouseButton )
	if self.wndConfirm:IsShown() then
		self.wndConfirm:Show(false)
	else 
		self.wndConfirm:Show(true)
	end
end

function LootSquid:OnConfirm( wndHandler, wndControl, eMouseButton )
	self.wndConfirm:Show(false)
	if wndHandler:GetName() == "Randomly" then
		self:OnRandom()
	elseif wndHandler:GetName() == "ToSelf" then
		self:OnToSelf()
	end
end

function LootSquid:OnRandom()
	for _, window in pairs(self.tItemWindows) do
		while true do
			if #self.tMemberList <= #self.tRandomLooters then self.tRandomLooters = {} end				
			local name = self.tMemberList[math.random(#self.tMemberList)]
			if self.tRandomLooters[name] == nil then
				table.insert(self.tQueuedItems, {item = window:GetData().nLootId, name = name})
				self.tRandomLooters[name] = window:GetData().nLootId
				break
			end
		end
	end
end

function LootSquid:OnToSelf()
	name = GameLib:GetPlayerUnit():GetName()
	for _, window in pairs(self.tItemWindows) do
		table.insert(self.tQueuedItems, {item = window:GetData().nLootId, name = name})
	end
end

local LootSquidInstance = LootSquid:new()
LootSquidInstance:Init()


