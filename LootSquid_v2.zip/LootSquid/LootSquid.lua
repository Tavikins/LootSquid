--LootSquid v2 by Tavi

require "Apollo"
require "GameLib"
require "Item"

local LootSquid = {}
local version = 2

function LootSquid:new(o)
	o = o or {}
	setmetatable(o, self)
	self.__index = self
	return o
end

function LootSquid:Init()
	Apollo.RegisterAddon(self)
end

local tDefaultSettings = {
	Mark = false,
	AutoLoot = false,
	AutoLootBoe = false,
	AutoSize = false,
	Queue = true,
	Hide = false,
	Opacity = 75,
	First = true,
	FormClosed = false,
	Version = version,
}

local tSettings

-- Guild-stuff list for Auto-loot:
local ktAutoLoot = {
	"Divine Class Focus - Major",
	"Divine Class Focus - Minor",
	"Divine Set Focus - Major",
	"Divine Set Focus - Minor",
	"Pure Class Focus - Major",
	"Pure Class Focus - Minor",
	"Pure Set Focus - Major",
	"Pure Set Focus - Minor",
	"Datascape Matrix",
	"Genetic Matrix",
	"Tarnished Eldan Gift",
	"Encrypted Datashard",
}

--Bind on Equip list for Auto-loot:
local ktBoeList = {
	--GA Items (iLvl 96)
	"Inoculation Resonators",				-- Support Resonators
	"Hyperproliferative Denims",			-- Heavy Assault Chest
	"Rib-Boned Breastplate",				-- Heavy Assault Chest
	"Poly-Tendered Waders",					-- Heavy Assault Legs
	"Insertional Stamina Gene",				-- Assault Weapon Attachment
	"Calcified Longbone",					-- Assault Sword
	"Scattershot Dispersion Blaster",		-- Support Heavy Gun
	"Overspecialized Regenerators",			-- Medium Assault Hands
	"Targeted Viral Coat",					-- Light Assault Chest
	"Dormant Phase Duster",					-- Light Support Chest
	"Meningeal Vest",						-- Light Assault Chest
	"Biomimetic Slashers",					-- Support Claws
	"Curved Strain Phalanges",				-- Support Support System
	"Genetic Redundancy Revolvers",			-- Support Pistols
	"Hallucinatory Secretions",				-- Assault Implant
	
	--DS Items (iLvl 116)
	"Crystalline Multiphasic Slicers",		-- Assault Claws
	"Intrusive Espernetic Technopants",		-- Light Assault Legs
	"Sympathetic Espernetic Neuroblade",	-- Support Psyblade
	"Stellar Binarymesh Shoulder Boards",	-- Heavy Support Shoulders
	"Electrolined Handscapes",				-- Heavy Assault Hands
	"Dynamic Onslaught Terminal",			-- Support Weapon Attachment
	"Stellar Binarymesh Gravblade",			-- Support Sword
	"Phage-Clogged Howitzer",				-- Assault Heavy Gun
	"Biomimetic Receptive Cowl",			-- Medium Support Helm
	"Invasive Biomimetic Zapinators",		-- Assault Resonators
	"Biomimetic Receptive Zapinators",		-- Support Resonators
	"Crystalline Multiphasic Flexisuit",	-- Medium Assault Chest
	"Defiant Multiphasic Visor",			-- Medium Support Helm
	"Heart of the Claw",					-- Light Assault Chest
	"Gloomsheath",							-- Light Support Chest
	"Precision Heavy-Bore Painmakers",		-- Assault Pistols
	"Intrusive Augmentor",					-- Assault Support System
	"Protective Multiphasic Deflector",		-- Tank Shield
	"Defiant Multiphasic Deflector",		-- Tank Shield
}

local ktClassToIcon = {
	[GameLib.CodeEnumClass.Medic]       	= "Icon_Windows_UI_CRB_Medic",
	[GameLib.CodeEnumClass.Esper]       	= "Icon_Windows_UI_CRB_Esper",
	[GameLib.CodeEnumClass.Warrior]     	= "Icon_Windows_UI_CRB_Warrior",
	[GameLib.CodeEnumClass.Stalker]     	= "Icon_Windows_UI_CRB_Stalker",
	[GameLib.CodeEnumClass.Engineer]    	= "Icon_Windows_UI_CRB_Engineer",
	[GameLib.CodeEnumClass.Spellslinger]  	= "Icon_Windows_UI_CRB_Spellslinger",
}

local karItemColors = {
	[Item.CodeEnumItemQuality.Inferior] 		= "ItemQuality_Inferior",
	[Item.CodeEnumItemQuality.Average] 			= "ItemQuality_Average",
	[Item.CodeEnumItemQuality.Good] 			= "ItemQuality_Good",
	[Item.CodeEnumItemQuality.Excellent] 		= "ItemQuality_Excellent",
	[Item.CodeEnumItemQuality.Superb] 			= "ItemQuality_Superb",
	[Item.CodeEnumItemQuality.Legendary] 		= "ItemQuality_Legendary",
	[Item.CodeEnumItemQuality.Artifact]		 	= "ItemQuality_Artifact",
}


function LootSquid:OnLoad()
    self.xmlDoc = XmlDoc.CreateFromFile("LootSquid.xml")
    self.xmlDoc:RegisterCallback("OnDocumentReady", self)

	Apollo.RegisterSlashCommand("ls", "OnSlashCommand", self)
	Apollo.RegisterSlashCommand("lootsquid", "OnSlashCommand", self)

	Apollo.RegisterTimerHandler("RandomAllTimer", "OnRandomAllTimer", self)
	Apollo.RegisterTimerHandler("ResizeTimer", "OnResizeTimer", self)
	
	Apollo.RegisterEventHandler("MasterLootUpdate",				"OnMasterLootUpdate", self)
	Apollo.RegisterEventHandler("LootAssigned",					"OnLootAssigned", self)
	Apollo.RegisterEventHandler("Group_Left",					"OnGroup_Left", self)
	Apollo.RegisterEventHandler("GenericEvent_ToggleGroupBag", 	"OnToggleGroupBag", self)
	

	
end

function LootSquid:OnDocumentReady()
    if self.xmlDoc == nil then return end

	if tSettings == nil then
		tSettings = tDefaultSettings
	end
	
	for key, value in pairs(tDefaultSettings) do
		if tSettings[key] == nil then
			tSettings[key] = value
		end
	end
	
	if tSettings.Version < version then
		tSettings.Version = version
		tSettings.First = true
	end
	
	--self.wndLoot = Apollo.LoadForm(self.xmlDoc, "Loot", nil, self)
	self.wndSettings = Apollo.LoadForm(self.xmlDoc, "Settings", nil, self)
	self.wndForm = Apollo.LoadForm(self.xmlDoc, "Form", nil, self)
	--self.wndCollapsed = Apollo.LoadForm(self.xmlDoc, "Collapsed", nil, self)
	self.wndMain = self.wndForm:FindChild("Main")
	self.wndItemList = self.wndMain:FindChild("ItemWindow"):FindChild("ItemList")
	self.wndPlayerList = self.wndMain:FindChild("PlayerWindow"):FindChild("PlayerList")
	self.wndOptions = self.wndSettings:FindChild("Options")
	self.wndTitle = self.wndForm:FindChild("Title")
	self.wndConfirm = self.wndTitle:FindChild("MLTitle"):FindChild("All"):FindChild("Confirm")
	self.RandomTimer = ApolloTimer.Create(0.1, true, "OnRandomAllTimer", self)
	
	self.tCheckedItems = {}
	self.tItemWindows = {}
	self.tGroupMembers = {}
	self.tPlayerWindows = {}
	self.tItemsToLoot = {}
	self.tQueuedItems = {}
	self.tMemberList = {}
	self.tRandomLooters = {}
	self.bLeader = false
	self.bRandoming = false
	math.randomseed(os.time())
	
	self.wndSettings:Show(tSettings.First)
	tSettings.First = false
	tSettings.FormClosed = false
		
	self.wndMain:FindChild("ItemWindow"):FindChild("BG"):SetOpacity(tSettings.Opacity, 100)
	self.wndMain:FindChild("PlayerWindow"):FindChild("BG"):SetOpacity(tSettings.Opacity, 100)
	self.wndOptions:FindChild("Opacity"):FindChild("Slider"):SetValue(tSettings.Opacity)
	self.wndTitle:FindChild("Show"):Show(tSettings.Hide)
	self.wndTitle:FindChild("Hide"):Show(not tSettings.Hide)
	self.wndConfirm:Show(false)
	
	local strTooltip = "To edit, find \"ktAutoLoot\" in LootSquid.lua (Line:36): \n \n"
	for idx, strItem in ipairs(ktAutoLoot) do
		strTooltip = strTooltip..strItem.."\n"
	end
	
	self.wndSettings:FindChild("Options"):FindChild("AutoLoot"):FindChild("Tooltip"):SetTooltip(strTooltip)
	
	strTooltip = "To edit, find \"ktBoeList\" in LootSquid.lua (Line:52): \n \n"
	for idx, strItem in ipairs(ktBoeList) do
		strTooltip = strTooltip..strItem.."\n"
	end
	
	self.wndSettings:FindChild("Options"):FindChild("AutoLootBoe"):FindChild("Tooltip"):SetTooltip(strTooltip)
	if tSettings.MainLocation then
		local l,t,r,b = unpack(tSettings.MainLocation)
		self.wndMain:SetAnchorOffsets(l,t,r,b)
	end
	if tSettings.SettingsLocation then
		local l,t,r,b = unpack(tSettings.SettingsLocation)
		self.wndSettings:SetAnchorOffsets(l,t,r,b)
	end
	if tSettings.FormLocation then
		local l,t,r,b = unpack(tSettings.FormLocation)
		self.wndForm:SetAnchorOffsets(l,t,r,b)
	end
	
	if next(GameLib.GetMasterLoot()) then
		self.wndForm:Show(true)
		self.wndMain:Show(true)
		self:OnMasterLootUpdate()
	else
		self.wndForm:Show(false)
	end

	
end
	
---------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------

function LootSquid:OnMasterLootUpdate()
	local tItemList = GameLib.GetMasterLoot()
	local l,t,r,b = self.wndMain:GetAnchorOffsets()
	tSettings.MainLocation = {l,t,r,b}
	l,t,r,b = self.wndForm:GetAnchorOffsets()
	tSettings.FormLocation = {l,t,r,b}
	local PlayerInCombat = GameLib.GetPlayerUnit():IsInCombat()
	
	if tSettings.Mark and GroupLib.AmILeader() and not GameLib.GetPlayerUnit():GetTargetMarker() then
		GameLib.GetPlayerUnit():SetTargetMarker(4)
	end
	
	self.wndMain:FindChild("PlayerWindow"):Show(GroupLib.AmILeader() and not tSettings.Hide)
	self.wndTitle:FindChild("MLTitle"):Show(GroupLib.AmILeader() and not tSettings.Hide)
	self.wndForm:Show(not tSettings.FormClosed)
	self.wndMain:Show(not tSettings.Hide)
	self.wndTitle:FindChild("Text"):SetTextColor("xkcdWhite")
	self:AutoSize(tSettings.AutoSize)
	
	-- update list with items
	if next(tItemList) then
		self:RefreshItemList(tItemList)
		if tSettings.Hide then
			self.wndTitle:FindChild("Text"):SetTextColor("xkcdGreen")
		end
	else
		self.tQueuedItems = {}
	end
	
end

function LootSquid:RefreshItemList(tItemList)
	local nVPos = self.wndItemList:GetVScrollPos()
	
	self.tItemWindows = {}
	self.tCheckedItems = {}
	
	for _,window in pairs(self.wndItemList:GetChildren()) do
		if window:IsChecked() then 
			self.tCheckedItems[window:GetData().nLootId] = true
		end
		window:Destroy()
	end
	
	for idx, tItem in pairs(tItemList) do
		local wndCurrentItem = Apollo.LoadForm(self.xmlDoc, "ListItem", self.wndItemList, self)
		table.insert(self.tItemWindows, wndCurrentItem)
		wndCurrentItem:FindChild("Icon"):GetWindowSubclass():SetItem(tItem.itemDrop)
		wndCurrentItem:FindChild("Name"):SetText(tItem.itemDrop:GetName())
		wndCurrentItem:FindChild("Name"):SetTextColor(karItemColors[tItem.itemDrop:GetItemQuality()])		
		wndCurrentItem:SetData(tItem)
		wndCurrentItem:FindChild("Random"):Show(GroupLib.AmILeader())
		
		if GroupLib.AmILeader() then
			if tSettings.AutoLoot then
				for _, strItemName in ipairs(ktAutoLoot) do
					if tItem.itemDrop:GetName() == strItemName then
						table.insert(self.tQueuedItems, {item = tItem.nLootId, name = GameLib.GetPlayerUnit():GetName()})
					end
				end
			end
			if tSettings.AutoLootBoe then
				for _, strItemName in ipairs(ktBoeList) do
					if tItem.itemDrop:GetName() == strItemName then
						table.insert(self.tQueuedItems, {item = tItem.nLootId, name = GameLib.GetPlayerUnit():GetName()})
					end
				end
			end
		end
		
		for _, tData in pairs(self.tQueuedItems) do
			if tData.item == tItem.nLootId then
				tItem.queued = true
				wndCurrentItem:SetData(tItem)
				wndCurrentItem:FindChild("Name"):SetText("(Queued:"..tData.name..") "..tItem.itemDrop:GetName())
				for _, unitLooter in pairs(tItem.tLooters) do
					local strLooterName = unitLooter:GetName()
					if strLooterName == tData.name then
						GameLib.AssignMasterLoot(tData.item, unitLooter)
					end
				end
			end
		end
		
		if self.tCheckedItems[tItem.nLootId] == true then
			wndCurrentItem:SetCheck(true)
			self:RefreshPlayerList(tItem)
		end
		
	end
	
	self.wndItemList:ArrangeChildrenVert(Window.CodeEnumArrangeOrigin.LeftOrTop)
	self.wndItemList:SetVScrollPos(nVPos)
	self:AutoSize(tSettings.AutoSize)

end

function LootSquid:RefreshPlayerList(tItem)
	if tItem == nil then
		--self.wndPlayerList:Show(false)
		for idx, wndPlayer in pairs(self.wndPlayerList:GetChildren()) do
			wndPlayer:Destroy()
		end
		return
	end
	
	local vPos = self.wndPlayerList:GetVScrollPos()
	
	self.CheckedPlayer = nil
	for _, window in pairs(self.wndPlayerList:GetChildren()) do
		if window:IsChecked() == true then
			self.CheckedPlayer = window:GetName()
		end
		window:Destroy()
	end
	self.tPlayerWindows = {}
	
	local tValidMembers = {}
	local nMemberCount = GroupLib.GetMemberCount()
	self.tMemberList = {}
	

	if tItem.tLooters and next(tItem.tLooters) then
		for idx, unitMember in pairs(tItem.tLooters) do
			local name = unitMember:GetName()
			local tData = { name = name, unit = unitMember, item = tItem, queue = false }
			
			table.insert(self.tMemberList, tData)
			self.tPlayerWindows[name] = Apollo.LoadForm(self.xmlDoc, "ListPlayer", self.wndPlayerList, self)
			self.tPlayerWindows[name]:FindChild("Name"):SetText(name)
			self.tPlayerWindows[name]:FindChild("Icon"):SetSprite(ktClassToIcon[unitMember:GetClassId()])
			self.tPlayerWindows[name]:SetName(name)
			self.tPlayerWindows[name]:SetData(tData)
			self.tPlayerWindows[name]:Show(true)
		end
	end
		
	if tItem.tLootersOutOfRange and next(tItem.tLootersOutOfRange) then
		for idx, name in ipairs(tItem.tLootersOutOfRange) do
			local tData = { name = name, item = tItem, queue = true}
			
			table.insert(self.tMemberList, tData)
			self.tPlayerWindows[name] = Apollo.LoadForm(self.xmlDoc, "ListPlayer", self.wndPlayerList, self)
			self.tPlayerWindows[name]:FindChild("Name"):SetText(String_GetWeaselString(Apollo.GetString("Group_OutOfRange"), name))
			self.tPlayerWindows[name]:FindChild("Icon"):SetSprite("CRB_GroupFrame:sprGroup_Disconnected")
			self.tPlayerWindows[name]:SetName(name)
			self.tPlayerWindows[name]:SetData(tData)
			self.tPlayerWindows[name]:Show(true)		
		end
	end
	
	if self.CheckedPlayer ~= nil then
		self.tPlayerWindows[self.CheckedPlayer]:SetCheck(true)
	end
	
	self.wndPlayerList:ArrangeChildrenVert(Window.CodeEnumArrangeOrigin.LeftOrTop, function(a,b)
		return a:FindChild("Name"):GetText() < b:FindChild("Name"):GetText()
	end)
	self.wndPlayerList:SetVScrollPos(vPos)
end


function LootSquid:OnGroup_Left()
	if self.wndForm:IsShown() then
		self:OnClose()
	end
end


function LootSquid:OnItemGenerateTooltip(wndHandler, wndControl, eToolTipType, x, y)
	if wndHandler ~= wndControl then
		return
	end

	local tItem = wndControl:GetData()	
	if Tooltip ~= nil and Tooltip.GetItemTooltipForm ~= nil then
		Tooltip.GetItemTooltipForm(self, wndControl, tItem.itemDrop, {bPrimary = true, bSelling = false, itemCompare = tItem.itemDrop:GetEquippedItemForItemType()})
	end
end


function LootSquid:OnItemMouseButtonUp(wndHandler, wndControl, eMouseButton)
	if eMouseButton == GameLib.CodeEnumInputMouse.Right then
		local tItemInfo = wndHandler:GetData()
		if tItemInfo and tItemInfo.itemDrop then
			Event_FireGenericEvent("GenericEvent_ContextMenuItem", tItemInfo.itemDrop)
		end
	end
end

function LootSquid:OnItemCheck(wndHandler, wndControl, eMouseButton)
	if eMouseButton ~= GameLib.CodeEnumInputMouse.Right then
		if not GroupLib.AmILeader() then wndHandler:SetCheck(false) return end
		local tItemInfo = wndHandler:GetData()
		if tItemInfo then
			table.insert(self.tItemsToLoot, tItemInfo)
			self:RefreshPlayerList(tItemInfo)
		end
	end
end

function LootSquid:OnItemUncheck(wndHandler, wndControl, eMouseButton)
	if eMouseButton ~= GameLib.CodeEnumInputMouse.Right then
		local tItemInfo = wndHandler:GetData()
		if tItemInfo then
			for idx, tItem in ipairs(self.tItemsToLoot) do
				if tItem.nLootId == tItemInfo.nLootId then
					table.remove(self.tItemsToLoot, idx)
				end
			end
		end
		local itemschecked = false
		for _, window in pairs(self.tItemWindows) do
			if window:IsChecked() then
				itemschecked = true
			end
		end
		if not itemschecked then
			self:RefreshPlayerList(nil)
		end
	end
end

----------------------------

function LootSquid:OnAssignLoot(wndHandler)
	local tData = wndHandler:GetData()
	if tData.queue and tData.queue == true then
		for i, itemtoloot in ipairs(self.tItemsToLoot) do
			table.insert(self.tQueuedItems, { item = itemtoloot.nLootId, name = tData.name })
			for _, window in pairs(self.tItemWindows) do
				if window:GetData().nLootId == itemtoloot.nLootId then
					local itemdata = window:GetData()
					itemdata.queued = true
					window:SetData(itemdata)
					window:FindChild("Name"):SetText("(Queued:"..tData.name..") "..itemtoloot.itemDrop:GetName())
					window:SetCheck(false)
				end
			end
		end
	else
		for idx, Item in ipairs(self.tItemsToLoot) do
			GameLib.AssignMasterLoot(Item.nLootId, tData.unit)
		end
	end
	self.tItemsToLoot = {}
	self:RefreshPlayerList(nil)
end

----------------------------

function LootSquid:AutoSize(b)
	if not b then return end
	--[[
	pcall(self.wndItemList:SetHeightToContentHeight(5))
	pcall(self.wndPlayerList:SetHeightToContentHeight(5))
	pcall(self.wndMain:SetHeightToContentHeight(5))
	]]
end

function LootSquid:OnClose(wndHandler, wndControl, eMouseButton)
	self.wndForm:Show(false)
	tSettings.FormClosed = true
end

function LootSquid:OnLootAssigned(objItem, strLooter)
	Event_FireGenericEvent("GenericEvent_LootChannelMessage", String_GetWeaselString(Apollo.GetString("CRB_MasterLoot_AssignMsg"), objItem:GetName(), strLooter))
	self:OnRefresh()
end

function LootSquid:OnCloseWindow( wndHandler, wndControl, eMouseButton )
	local l,t,r,b = self.wndSettings:GetAnchorOffsets()
	tSettings.SettingsLocation = {l,t,r,b}
	self.wndSettings:Show(false)
end

function LootSquid:OnDefaults( wndHandler, wndControl, eMouseButton )
	tSettings = tDefaultSettings
	self:RefreshSettings()
end

function LootSquid:RefreshSettings()
	self.wndOptions:FindChild("Mark"):SetCheck(tSettings.Mark)
	self.wndOptions:FindChild("AutoLoot"):SetCheck(tSettings.AutoLoot)
	self.wndOptions:FindChild("AutoLootBoe"):SetCheck(tSettings.AutoLootBoe)
	self.wndOptions:FindChild("Opacity"):FindChild("Slider"):SetValue(tSettings.Opacity)
end

function LootSquid:OnOptionChanged( wndHandler, wndControl, strText )
	local option = wndHandler:GetName()
	if option == nil then return end
	tSettings[option] = wndHandler:GetText()
end

function LootSquid:OnCheckbox( wndHandler, wndControl, eMouseButton )
	local option = wndHandler:GetName()
	if option == nil then return end
	tSettings[option] = wndHandler:IsChecked()
end

function LootSquid:OnSlashCommand()
	self:RefreshSettings()
	if not self.wndForm:IsShown() then
		self.wndForm:Show(true)
		tSettings.FormClosed = false
	else
		self.wndForm:Show(false)
		tSettings.FormClosed = true
		Print("Type \"/ls\" to show the loot window again")
	end
	self:OnMasterLootUpdate()
end	

function LootSquid:OnOptionsButton( wndHandler, wndControl, eMouseButton )
	self:RefreshSettings()
	if not self.wndSettings:IsShown() then
		self.wndSettings:Show(true)
	else
		self.wndSettings:Show(false)
	end
end

function LootSquid:OnRestore(eLevel, tData)
	if eLevel ~= GameLib.CodeEnumAddonSaveLevel.Character then return end
	if tData then
		tSettings = tData
	end
end

function LootSquid:OnSave(eLevel)
	if eLevel ~= GameLib.CodeEnumAddonSaveLevel.Character then return end
	local l,t,r,b
	
	l,t,r,b = self.wndMain:GetAnchorOffsets()
	tSettings.MainLocation = {l,t,r,b}
	
	l,t,r,b = self.wndForm:GetAnchorOffsets()
	tSettings.FormLocation = {l,t,r,b}
	
	return tSettings
end

function strRound(nSource, nDecimals)
    return tonumber(string.format("%." .. (nDecimals or 0) .. "f", nSource))
end


function LootSquid:OnHide( wndHandler, wndControl, eMouseButton )
	self.wndTitle:FindChild("Hide"):Show(false)
	self.wndTitle:FindChild("Show"):Show(true)
	self.wndMain:Show(false)
	self.wndTitle:FindChild("MLTitle"):Show(false)
	self.wndMain:FindChild("PlayerWindow"):Show(false)
	tSettings.Hide = true
end

function LootSquid:OnShow( wndHandler, wndControl, eMouseButton )
	self.wndTitle:FindChild("Hide"):Show(true)
	self.wndTitle:FindChild("Show"):Show(false)
	self.wndMain:Show(true)
	self.wndTitle:FindChild("MLTitle"):Show(GroupLib.AmILeader())
	self.wndMain:FindChild("PlayerWindow"):Show(GroupLib.AmILeader())
	tSettings.Hide = false
end

function LootSquid:OnMainResize( wndHandler, wndControl )
	Apollo.StopTimer("ResizeTimer")
	Apollo.CreateTimer("ResizeTimer", 0.1, false)
	local l,t,r,b = self.wndForm:GetAnchorOffsets()
	self.formsize = {l,t,r,b}
	if not self.Resized then
		self.Resized = true
	end
end

function LootSquid:OnResizeTimer()
	local l,t,r,b = self.wndMain:GetAnchorOffsets()
	self.wndTitle:SetAnchorOffsets(l,t,r/2,30)
	local d = r - l
	local l,t,r,b = unpack(self.formsize)
	self.wndForm:SetAnchorOffsets(l,t,l + (d/2),t + 30)
	self.Resized = nil
end

function LootSquid:OnAllButton( wndHandler, wndControl, eMouseButton )
	if self.wndConfirm:IsShown() then
		self.wndConfirm:Show(false)
	else 
		self.wndConfirm:Show(true)
	end
end

function LootSquid:OnConfirm( wndHandler, wndControl, eMouseButton )
	self.wndConfirm:Show(false)
	if wndHandler:GetName() == "Randomly" then
		self:OnRandom()
	elseif wndHandler:GetName() == "ToSelf" then
		self:OnToSelf()
	end
end

function LootSquid:OnRandom()
	self:OnRefresh()
	self.bRandoming = true
	self.RandomTimer:Start()
end

function LootSquid:OnRandomAllTimer()
	if self.bRandoming == false then
		self.RandomTimer:Stop()
		return
	end
	if #self.tItemWindows == 0 then
		self.bRandoming = false
		return
	end
	local tData
	for i, window in ipairs(self.tItemWindows) do
		if i == #self.tItemWindows and window:GetData() and window:GetData().queued == true then 
			Print("Randoming Complete")
			self.bRandoming = false 
			return 
		end
		tData = nil
		tData = window:GetData()
		if tData and not tData.queued then 
			break 
		end
	end
	if tData == nil then 
		Print("Randoming Complete")
		self.bRandoming = false
		return
	end
	
	self:RefreshPlayerList(tData)
	
	if #self.tRandomLooters == 0 then
		if #self.tMemberList == 0 then
			Print("Error - tMemberList is empty...?")
			self.bRandoming = false
			return
		end
		self.tRandomLooters = self.tMemberList
	end
	
	local item = tData.nLootId
	local random = math.random(#self.tRandomLooters)
	local name = self.tRandomLooters[random].name
	table.insert(self.tQueuedItems, {item = item, name = name})
	table.remove(self.tRandomLooters, random)
	
	self:RefreshPlayerList(nil)
	self:OnRefresh()
end

function LootSquid:OnToSelf()
	name = GameLib:GetPlayerUnit():GetName()
	for _, window in pairs(self.tItemWindows) do
		table.insert(self.tQueuedItems, {item = window:GetData().nLootId, name = name})
	end
	self:RefreshPlayerList(nil)
	self:OnRefresh()
end

function LootSquid:OnOpacitySlider( wndHandler, wndControl, fNewValue, fOldValue, bOkToChange )
	local value = self.wndOptions:FindChild("Opacity"):FindChild("Slider"):GetValue()
	tSettings.Opacity = value
	self.wndMain:FindChild("ItemWindow"):FindChild("BG"):SetOpacity(value, 100)
	self.wndMain:FindChild("PlayerWindow"):FindChild("BG"):SetOpacity(value, 100)
end

function LootSquid:OnItemRandom( wndHandler, wndControl, eMouseButton )
	local tData = wndHandler:GetParent():GetParent():GetData()
	self:RefreshPlayerList(tData)
	local name = self.tMemberList[math.random(#self.tMemberList)].name
	table.insert(self.tQueuedItems, {item = tData.nLootId, name = name})
	self:OnRefresh()
	self:RefreshPlayerList(nil)
end

function LootSquid:OnRefresh()
	for _, window in pairs(self.tItemWindows) do
		window:Destroy()
	end
	self:OnMasterLootUpdate()
end

local LootSquidInstance = LootSquid:new()
LootSquidInstance:Init()


